// Synchrone:
// va chercher d'abord le fichier avant de faire la suite



console.log('Hello World !')

var fssync = require('fs');

var files =fssync.readdirSync('.'); //va chercher dans le dossier et donner le nom des fichiers contenus

console.log(files);


//Asynchrone 
// va chercher le fichier en continuant d'executer la suite et c'est la particularité de node

var fsasync = require('fs');
fsasync.readdir('.', function fil(err,file){
	if (err){
		console.log('probleme');
	}else{
		for (var i = 0, l = file.length; i < l; i++){
			console.log(file[i])
		}
	}
});
