
var express = require('express');
var mon_app = express();

var count = 0;
var euro_forum = [
	{Sujet: ' Equipe de France', Texte: 'Benzema non selectionné car il est naz!'},
	{Sujet: 'Paris', Texte: 'les equipes vont jouer au sdf et au pdp'},
	{Sujet: 'Stade', Texte: 'dans quel stade se jouera la finale?'}
	]

//permet de voir le traffic les client conectées ect...
//mon_app.use(express.logger());

//acceder à des fichiers ou le contenu  est static cad qu'il ne va pas bouger avec les interactions
// __dirname cad dans mon dossier prend le dossier apres +
mon_app.use(express.static(__dirname + '/D_html'));

// création du dossier views pour les templates
mon_app.set('/views', __dirname + 'views');


//me permet d'utiliser body pour post
var body = require('body-parser');

mon_app.use( body.json() );       // to support JSON-encoded bodies

mon_app.use(body.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

mon_app.get('/', function (req, res) {
	res.render('home.ejs');
});


mon_app.get('/new_post', function (req, res) {
	res.render('new_post.ejs');
});


// LES ROUTES VONT APPELER DES FICHIER EJS CAR C'EST LA VUE /..
mon_app.get('/counter', function (req, res) {
	count += 1;
    //res.send('Hello World!Vous etes le visiteur : ' + count + ' sur cette page ');
    res.render('compteur.ejs',{count: count});
});


//au lieu de se repeter on va faire ce que tt bon programmeur ferais DRY don't repeat yourself
// on va mettre :id apres monstre pour accerder aux monstres
mon_app.get('/euro_forum/:id', function (req, res) {
	var forum_id = euro_forum[req.params.id -1];
	// id -1 car le tableau commence  à zero
	//res.send(forum_id.Sujet+' '+ forum_id.Texte);
	//res.render('euro_f.ejs',{forum_id: forum_id}
	res.render('euro_f.ejs',{forum_id: forum_id});
});


//quand on fait un post les parametres sont dans le body
mon_app.post('/post', function (req, res) {
	euro_forum.push({
		Sujet: req.body.Sujet,
		Texte: req.body.Texte

	});
	res.send("Validé");
});



mon_app.get('/users', function (req, res) {
	res.send("pas d'utilisateurs");
});

mon_app.listen(8000, function () {
  console.log('port 8000!');
});
