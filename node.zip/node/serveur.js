var create_f = require('./create_f.js');



create_f.server_f.listen('8000');// vas sur le file create_f et pointe server_f pour ecouter

console.log('connecté au serveur');